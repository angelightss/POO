package ex2;

public class Documento extends Arquivo {

    public Documento(String nome, int endereco, int total) {
        super(nome, endereco, total);
    }
} 